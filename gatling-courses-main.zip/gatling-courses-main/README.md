# gatling-courses
in this project you find simple test (TestSimulation) to see 
how start your education in Perfomance Testing on Gatling